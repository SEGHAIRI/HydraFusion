from config import Config
from hydranet import HydraFusion
from torch.utils.data import Dataset, DataLoader
import numpy as np
import json
import matplotlib.pyplot as plt
import os
from torchvision.models.detection.transform import GeneralizedRCNNTransform
import torch
from torch.utils.data import random_split
from radiate import Sequence

args= ''
configuration = Config(args)

Hydranet = HydraFusion(configuration)

print(Hydranet)

classe_id = {'car': 1, 'van' : 2, 'truck' : 3, 'bus' : 4, 'motorbike' : 5, 'bicycle' : 6, 'pedestrian' : 7, 'group_of_pedestrians' : 8}

def get_radar_annotation(idx, root):
    # Opening JSON file
    f = open(root + '/annotations/annotations.json')

    # returns JSON object as
    # a dictionary
    data = json.load(f)

    # Iterating through the json
    # list
    first_image = {}
    target={}
    targett=[]
    boxes = []
    labels = []
    boxe=[]
    for i in data:
        
        if i['bboxes'][idx]!=[]:
            boxe.append(i['bboxes'][idx]['position'][0])
            boxe.append(i['bboxes'][idx]['position'][1])
            boxe.append(i['bboxes'][idx]['position'][2] + i['bboxes'][idx]['position'][0])
            boxe.append(i['bboxes'][idx]['position'][3] + i['bboxes'][idx]['position'][1])
            first_image['boxes'] = boxe
            first_image['labels'] = int(classe_id[i['class_name']])
            labels.append(first_image['labels'])
            boxes.append(first_image['boxes'])
            first_image = {}
            boxe=[]
    target['boxes'] = torch.as_tensor(boxes, dtype=torch.float32)
    target['labels'] = torch.as_tensor(labels, dtype=torch.int64)
    # Closing file

    f.close()
    return target

def get_image_annotation(annotations):
    first_image = {}
    target={}
    targett=[]
    boxes = []
    labels = []
    boxe=[]
    for annotation in annotations:
      bboxe2d = annotation['bbox_3d']
      if np.array(bboxe2d).size!=0:
        if bboxe2d[0]>=0 and bboxe2d[2]>=0 and bboxe2d[0]< bboxe2d[2] and bboxe2d[1]< bboxe2d[3]  :
            boxe.append(bboxe2d[0])
            boxe.append(bboxe2d[1])
            boxe.append(bboxe2d[2])
            boxe.append(bboxe2d[3])
            first_image['boxes'] = boxe
            first_image['labels'] = int(classe_id[annotation['class_name']])
            labels.append(first_image['labels'])
            boxes.append(first_image['boxes'])
            first_image = {}
            boxe=[]
    target['boxes'] = torch.as_tensor(boxes, dtype=torch.float32)
    target['labels'] = torch.as_tensor(labels, dtype=torch.int64)

    return target

def get_lidar_annotation(annotations):
    target={}
    boxes = []
    labels = []
    boxe=[]
    for annotation in annotations:
        boxe.append(annotation['bbox']['position'][0])
        boxe.append(annotation['bbox']['position'][1])
        boxe.append(annotation['bbox']['position'][2] + annotation['bbox']['position'][0])
        boxe.append(annotation['bbox']['position'][3] + annotation['bbox']['position'][1])
        labels.append(int(classe_id[annotation['class_name']]))
        boxes.append(boxe)
        boxe=[]
    target['boxes'] = torch.as_tensor(boxes, dtype=torch.float32)
    target['labels'] = torch.as_tensor(labels, dtype=torch.int64)

    return target

class Radiate(Dataset):

    def __init__(self, root_dir, sequence):
        self.root = root_dir
        with open(root_dir + '/Navtech_Cartesian.txt') as f:
            self.lines = f.readlines()
        self.radar_annot = []
        self.image_annot = []
        self.lidar_annot = []
        self.Navtech_Cartesian = root_dir + '/Navtech_Cartesian'
        self.Navtech_Polar = root_dir + '/Navtech_Polar'
        self.zed_left = root_dir + '/zed_left'
        self.zed_right = root_dir + '/zed_right'
        for i in range(len(self.lines) - 1, -1, -1):
            Time_radar = self.lines[i][self.lines[i].find('Time')+6:]
            outputs = sequence.get_from_timestamp(t=float(Time_radar), get_sensors=True, get_annotations=True)
            idx = int(self.lines[i][self.lines[i].find(' ')+1:self.lines[i].rfind(' ')-6]) 
            radar_annot = get_radar_annotation(idx-1, root_dir)
            if np.array(radar_annot['boxes']).tolist()==[]:
              del self.lines[i]
            elif outputs == {}:
                del self.lines[i]
            else :
                image_annot = get_image_annotation(outputs['annotations']['camera_right_rect'])
                if image_annot['boxes'].tolist()==[]:
                    del self.lines[i]
    def __len__(self):
        return len(self.lines)

    def __getitem__(self, idx):

        #Radar data
        radar_cart = os.path.join(self.Navtech_Cartesian,
                                self.lines[idx][self.lines[idx].find(' ')+1:self.lines[idx].rfind(' ')-6]+'.png')
        target = get_radar_annotation(int(self.lines[idx][self.lines[idx].find(' ')+1:self.lines[idx].rfind(' ')-6])-1, self.root)
        area = (target['boxes'][:, 3] - target['boxes'][:, 1]) * (target['boxes'][:, 2] - target['boxes'][:, 0])
        iscrowd = torch.zeros((target['boxes'].shape[0],), dtype=torch.int64)
        target["area"] = area
        target["iscrowd"] = iscrowd    
        image_id = torch.tensor([idx])
        target["image_id"] = image_id
        self.radar_annot.append(target)
        radar_cart = plt.imread(radar_cart)
        radar_cart = radar_cart.reshape(1,radar_cart.shape[0],radar_cart.shape[1])
        # Annotation transformation
        Time_radar = self.lines[idx][self.lines[idx].find('Time')+6:]
        outputs = sequence.get_from_timestamp(t=float(Time_radar), get_sensors=True, get_annotations=True)
        #Right camera data
        image_camera_right = np.array(outputs['sensors']['camera_right_rect'], dtype = float)
        image_camera_right = image_camera_right.reshape(image_camera_right.shape[2],image_camera_right.shape[0],image_camera_right.shape[1])
        image_camera_left = np.array(outputs['sensors']['camera_left_rect'], dtype = float)
        image_camera_left = image_camera_left.reshape(image_camera_left.shape[2],image_camera_left.shape[0],image_camera_left.shape[1])
        target = get_image_annotation(outputs['annotations']['camera_right_rect'])
        area = (target['boxes'][:, 3] - target['boxes'][:, 1]) * (target['boxes'][:, 2] - target['boxes'][:, 0])
        iscrowd = torch.zeros((target['boxes'].shape[0],), dtype=torch.int64)
        target["area"] = area
        target["iscrowd"] = iscrowd    
        image_id = torch.tensor([idx])
        target["image_id"] = image_id
        self.image_annot.append(target)
        #LiDAR data
        lidar_bev_image = np.array(outputs['sensors']['lidar_bev_image'], dtype = float)
        lidar_bev_image = lidar_bev_image.reshape(lidar_bev_image.shape[2],lidar_bev_image.shape[0],lidar_bev_image.shape[1])
        target = get_lidar_annotation(outputs['annotations']['lidar_bev_image'])
        area = (target['boxes'][:, 3] - target['boxes'][:, 1]) * (target['boxes'][:, 2] - target['boxes'][:, 0])
        iscrowd = torch.zeros((target['boxes'].shape[0],), dtype=torch.int64)
        target["area"] = area
        target["iscrowd"] = iscrowd    
        image_id = torch.tensor([idx])
        target["image_id"] = image_id
        self.lidar_annot.append(target)
            
        return image_camera_right, image_camera_left, lidar_bev_image, radar_cart, self.image_annot, self.lidar_annot, self.radar_annot

path = "content/data"
dir_list = os.listdir(path)

root_dir = "content/data/" + dir_list[0]
sequence = Sequence(sequence_path=root_dir, config_file='config.yaml')
data = Radiate(root_dir,sequence)

for bb in  range(1,len(dir_list)):
    root_dir = "content/data/" + dir_list[bb]
    sequence = Sequence(sequence_path=root_dir, config_file='config.yaml')
    data = torch.utils.data.ConcatDataset([data, Radiate(root_dir,sequence)])

val_size = int(len(data)*0.4)
train_size = len(data) - val_size

generator = torch.Generator()
generator.manual_seed(0)

train_ds, val_ds = random_split(data, [train_size, val_size], generator=generator)

train_loader = DataLoader(train_ds, batch_size=1, shuffle=True)
valid_loader = DataLoader(val_ds, batch_size=1, shuffle=False)

class Averager:
    def __init__(self):
        self.current_total = 0.0
        self.iterations = 0.0
        
    def send(self, value):
        self.current_total += value
        self.iterations += 1
    
    @property
    def value(self):
        if self.iterations == 0:
            return 0
        else:
            return 1.0 * self.current_total / self.iterations
    
    def reset(self):
        self.current_total = 0.0
        self.iterations = 0.0

DEVICE = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
model = Hydranet
model = model.to(DEVICE)

params = [p for p in model.parameters() if p.requires_grad]

optimizer = torch.optim.SGD(params, lr=5e-3, momentum=0.9, weight_decay=0.0005)
#optimizer = torch.optim.Adam(params, lr=5e-3, betas=(0.9, 0.999), eps=1e-08, weight_decay=0, amsgrad=False, maximize=False)

class SaveBestModel:
    """
    Class to save the best model while training. If the current epoch's 
    validation loss is less than the previous least less, then save the
    model state.
    """
    def __init__(
        self, best_valid_loss=float('inf')
    ):
        self.best_valid_loss = best_valid_loss
        
    def __call__(
        self, current_valid_loss, 
        epoch, model, optimizer
    ):
        if current_valid_loss < self.best_valid_loss:
            self.best_valid_loss = current_valid_loss
            print(f"\nBest validation loss: {self.best_valid_loss}")
            print(f"\nSaving best model for epoch: {epoch+1}\n")
            torch.save({
                'epoch': epoch+1,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                }, 'content/best_model.pth')

def validate(valid_data_loader, model, printt):
    print('Validating')
    global val_itr
    global val_loss_list
    
    # initialize tqdm progress bar
    prog_bar = tqdm(valid_data_loader, total=len(valid_data_loader))
    
    for i, data in enumerate(prog_bar):
        losses = 0

        image_camera_right, image_camera_left, lidar_bev_image, radar_cart, image_annot, lidar_annot, radar_annot = data
        
        image_camera_right = list(image.to(DEVICE) for image in image_camera_right)
        image_camera_left = list(image.to(DEVICE) for image in image_camera_left)
        lidar_bev_image = list(image.to(DEVICE) for image in lidar_bev_image)
        radar_cart = list(image.to(DEVICE) for image in radar_cart)
        image_annot = [{k: v.to(DEVICE) for k, v in t.items()} for t in image_annot]
        lidar_annot = [{k: v.to(DEVICE) for k, v in t.items()} for t in lidar_annot]
        radar_annot = [{k: v.to(DEVICE) for k, v in t.items()} for t in radar_annot]
        with torch.no_grad():
            output_losses, output_detections = model.forward(leftcamera_x=image_camera_left, rightcamera_x=image_camera_right, radar_x=radar_cart, bev_lidar_x=lidar_bev_image, l_lidar_x=None, r_lidar_x=None, radar_y=radar_annot, cam_y=image_annot)
        
        for loss in output_losses.values():
            for los in loss:
                losses += loss[los]
        
        loss_value = losses
        val_loss_list.append(loss_value)
        val_loss_hist.send(loss_value)
        val_itr += 1
        # update the loss value beside the progress bar for each iteration
        prog_bar.set_description(desc=f"Loss: {loss_value:.4f}")
    return val_loss_list

def train(train_data_loader, model):
    print('Training')
    global train_itr
    global train_loss_list
    
     # initialize tqdm progress bar
    prog_bar = tqdm(train_data_loader, total=len(train_data_loader))
    
    for i, data in enumerate(prog_bar):
        losses = 0
        optimizer.zero_grad()
        image_camera_right, image_camera_left, lidar_bev_image, radar_cart, image_annot, lidar_annot, radar_annot = data
        
        image_camera_right = list(image.to(DEVICE) for image in image_camera_right)
        image_camera_left = list(image.to(DEVICE) for image in image_camera_left)
        lidar_bev_image = list(image.to(DEVICE) for image in lidar_bev_image)
        radar_cart = list(image.to(DEVICE) for image in radar_cart)
        image_annot = [{k: v.to(DEVICE) for k, v in t.items()} for t in image_annot]
        lidar_annot = [{k: v.to(DEVICE) for k, v in t.items()} for t in lidar_annot]
        radar_annot = [{k: v.to(DEVICE) for k, v in t.items()} for t in radar_annot]
        output_losses, output_detections = model.forward(leftcamera_x=image_camera_left, rightcamera_x=image_camera_right, radar_x=radar_cart, bev_lidar_x=lidar_bev_image, l_lidar_x=None, r_lidar_x=None, radar_y=radar_annot, cam_y=image_annot)
        losses = 0
        losses += sum(loss for loss in list(output_losses.values())[0].values())
        losses += sum(loss for loss in list(output_losses.values())[1].values())
        losses += sum(loss for loss in list(output_losses.values())[2].values()) 
        loss_value = losses.item()
        train_loss_list.append(loss_value)
        train_loss_hist.send(loss_value)
        losses.backward()
        optimizer.step()
        train_itr += 1
    
        # update the loss value beside the progress bar for each iteration
        prog_bar.set_description(desc=f"Loss: {loss_value:.4f}")
    return train_loss_list

def save_loss_plot(OUT_DIR, train_loss, val_loss):
    figure_1, train_ax = plt.subplots()
    figure_2, valid_ax = plt.subplots()
    train_ax.plot(train_loss, color='tab:blue')
    train_ax.set_xlabel('iterations')
    train_ax.set_ylabel('train loss')
    valid_ax.plot(val_loss, color='tab:red')
    valid_ax.set_xlabel('iterations')
    valid_ax.set_ylabel('validation loss')
    figure_1.savefig(f"{OUT_DIR}/train_loss.png")
    figure_2.savefig(f"{OUT_DIR}/valid_loss.png")
    print('SAVING PLOTS COMPLETE...')
    plt.close('all')
OUT_DIR = 'content'

def save_model(epoch, model, optimizer):
    """
    Function to save the trained model till current epoch, or whenver called
    """
    torch.save({
                'epoch': epoch+1,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                }, 'content/last_model.pth')

import time
from tqdm.auto import tqdm
# initialize the Averager class
train_loss_hist = Averager()
val_loss_hist = Averager()
train_itr = 1
val_itr = 1
# train and validation loss lists to store loss values of all...
# ... iterations till ena and plot graphs for all iterations
train_loss_list = []
val_loss_list = []

# initialize SaveBestModel class
save_best_model = SaveBestModel()

NUM_EPOCHS = 1000
for epoch in range(NUM_EPOCHS):
    printt = False
    print(f"\nEPOCH {epoch+1} of {NUM_EPOCHS}")
    # reset the training and validation loss histories for the current epoch
    train_loss_hist.reset()
    val_loss_hist.reset()
    # start timer and carry out training and validation
    start = time.time()
    model.train()
    train_loss = train(train_loader, model)
    model.eval()
    model.training
    if epoch%10==0:
        printt = True
    val_loss = validate(valid_loader, model, printt)

    print(f"Epoch #{epoch+1} train loss: {train_loss_hist.value:.3f}")  
    print(f"Epoch #{epoch+1} validation loss: {val_loss_hist.value:.3f}")      
    end = time.time()
    print(f"Took {((end - start) / 60):.3f} minutes for epoch {epoch}")
    # save the best model till now if we have the least loss in the...
    # ... current epoch
    save_best_model(
        val_loss_hist.value, epoch, model, optimizer
    )
    # save the current epoch model
    save_model(epoch, model, optimizer)
    # save loss plot
    
    save_loss_plot(OUT_DIR, train_loss, val_loss)
    # sleep for 5 seconds after each epoch
    time.sleep(5)

